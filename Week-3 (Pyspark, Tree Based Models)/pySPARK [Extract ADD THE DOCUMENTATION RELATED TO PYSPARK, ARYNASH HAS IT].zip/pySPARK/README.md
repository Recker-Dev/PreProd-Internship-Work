# Intial prerequisites

1. Create a new virtual environment; as I have conda installed, I used the specific commands.

   - Created a virtual environment here i named it pyspark_env
   - `conda create --name pyspark_env  python=3.10`
   - `conda env list` to see the virual environment list on the system.

2. Get the necessary libraries in the kernel; _do this in cmd prompt or powershell, vs code terminal for conda acts weird_ .

   - `pip install ipykernel`
   - `pip install pyspark`

3. Shortcut.
   - Use Google Colab to skip all the steps, and avoid Spark related issues.
   - Need to configure drive and dataset link though.
     -"/content/drive/My Drive/{remaining path to the dataset}"

# PySpark Data Exploration and Transformation

This project demonstrates basic PySpark operations for data exploration, transformation, and analysis using a sample order and customer dataset.

## Description

The script performs the following operations:

- Reading data from CSV files into PySpark DataFrames.
- Exploring the data schema, data types, and descriptive statistics.
- Handling missing values using various techniques like dropping, filling, and imputation.
- Applying filter operations to select specific rows based on conditions.
- Performing group-by aggregations to calculate summary statistics.
- Joining two DataFrames based on a common key (customer_id).
- Manipulating date columns to convert string dates to proper date data types.

## Datasets Used

- **pyspark_order_table_modified.csv:** Contains order data with customer and product information.
- **pyspark_customer_table.csv:** Contains customer information.

## Operations Carried Out

1. **Data Loading:** Reading CSV files into PySpark DataFrames.
2. **Data Exploration:** Examining data schema, data types, and descriptive statistics.
3. **Missing Value Handling:** Dropping, filling, and imputing missing values.
4. **Filter Operations:** Selecting specific rows using where and filter clauses.
5. **Group-by Aggregations:** Calculating summary statistics using groupBy and aggregation functions.
6. **Join Operations:** Joining DataFrames using inner, left, right, and outer joins.
7. **Date Manipulation:** Converting string dates to proper date data types.

## Usage

1. Ensure you have PySpark installed and configured.
2. Run the script in a Google Colab environment(<b>preferred to avoid Spark Related issues</b>) or a Jupyter notebook.
3. Make sure the dataset files are accessible in the specified paths.
4. Execute the code cells sequentially to perform the desired operations.
