└── root
├── datasets
│ ├── pyspark_order_table_modified.csv
│ ├── pyspark_customer_table.csv
| └── pyspark_order_table.csv
├── pySpark.ipynb 
├── metadata.json
├── prompts.md
├── README.md
└── requirements.txt
└── sqljoins.png
